var goals = [{ x: 920, w: 920 + 250, y: 267, h: 267 + 70 },
{ x: 920, w: 920 + 250, y: 350, h: 350 + 70 },
{ x: 920, w: 920 + 250, y: 433, h: 433 + 70 },
{ x: 920, w: 920 + 250, y: 516, h: 516 + 70 },
{ x: 920, w: 920 + 250, y: 599, h: 599 + 70 },
]
var nodes = [{
	x: 500,
	y: 270,
}, {
	x: 500,
	y: 350,
}, {
	x: 500,
	y: 433,
}
	, {
		x: 500,
	y: 516,
}
	, {
		x: 500,
	y: 599,
}
]

var isBoundryEntered = (clientX, clientY) => {
	let isEntered = false;
	goals.map(item => {
		if (clientX >= item.x && clientY >= item.y && clientX <= item.w && clientY <= item.h) {
			isEntered = true;
			return;
		}
	});
	return isEntered;
}

var checkMouseCollision = ({clientX, clientY}, _x, _y) => {
	console.log({ clientX, clientY }, _x, _y)
	if (clientX >= _x && clientY >= _y && clientY <= _y + 70 && clientX <= _x + 250) {	
		return true;
	}
}

let physicalObjects = [];
window.onload = function () {

	var canvas = document.getElementById("canvas"),
		context = canvas.getContext("2d"),
		width = canvas.width = window.innerWidth,
		height = canvas.height = window.innerHeight;
	nodes.map((node, index) => {
		physicalObjects[index] = {};
		physicalObjects[index].springPoint = vector.create(node.x, node.y);
		physicalObjects[index].weight = particle.create(node.x, node.y, 0, 0);

		document.getElementById(`spring${index + 1}`).addEventListener("drag", function (event) {
			physicalObjects[index].springPoint.setX(event.clientX);
			physicalObjects[index].springPoint.setY(event.clientY);
		});

		document.getElementById(`spring${index + 1}`).addEventListener("dragend", function (event) {
			console.log(event.clientX);
			if (isBoundryEntered(event.clientX, event.clientY)) {
				physicalObjects[index].springPoint.setX(event.clientX);
				physicalObjects[index].springPoint.setY(event.clientY);
				new Audio('./press.mp3').play()
			}
			else {
				physicalObjects[index].springPoint.setX(node.x);
				physicalObjects[index].springPoint.setY(node.y);
			}
		});

		document.body.addEventListener("click", function (event) {
			if (checkMouseCollision(event, physicalObjects[index].springPoint.getX(), physicalObjects[index].springPoint.getY())) {
				physicalObjects[index].springPoint.setX(node.x);
				physicalObjects[index].springPoint.setY(node.y);
			}
		});
	})


	update();

	function update() {
		context.clearRect(0, 0, width, height);

		physicalObjects.map(node => {
			node.weight.update();

			context.beginPath();
			context.arc(node.weight.position.getX(), node.weight.position.getY(), node.weight.radius,
				0, Math.PI * 2, false);
			context.fill();

			context.beginPath();

			roundedRectangle(node.springPoint.getX(), node.springPoint.getY(), 100, 60, context);

			context.fill();

			context.beginPath();

			context.moveTo(node.weight.position.getX(), node.weight.position.getY())+20;
			context.lineTo(node.springPoint.getX(), node.springPoint.getY());
			context.stroke();
		});
		requestAnimationFrame(update);
	}
};

function roundedRectangle(x, y, w, h, context) {
	var mx = x + w / 2;
	var my = y + h / 2;
	var img = document.getElementById("scream");
	context.drawImage(img, x, y);
}